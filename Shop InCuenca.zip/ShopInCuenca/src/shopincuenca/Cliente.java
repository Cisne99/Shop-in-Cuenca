/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopincuenca;

/**
 *
 * @author Usurio
 */
public class Cliente extends Persona{
    private String categoria; // Excelente, Bueno y Regular: esta categoria se da segun como empiecen las compras. Todos los clientes empiezan con categoria regular
    private int puntos; // Empieza en 0 y segun la cantidad de compras que haga el cliente aumentaran sus puntos para acceder a descuentos y ofertas
    private float descuento; //Segun los puntos accede a desceuntos

    public Cliente() {
        super();
    }

    public Cliente(String categoria, int puntos, float descuento, String cedula, String nombre, String apellido, String direccion, String celular, String edad, String usuario, String contraseña) {
        super(cedula, nombre, apellido, direccion, celular, edad, usuario, contraseña);
        this.categoria = categoria;
        this.puntos = puntos;
        this.descuento = descuento;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public float getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }
    
    
    
}
