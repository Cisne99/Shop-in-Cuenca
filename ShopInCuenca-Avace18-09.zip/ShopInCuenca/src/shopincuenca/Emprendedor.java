/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shopincuenca;

/**
 *
 * @author Usurio
 */
public class Emprendedor extends Persona{
    private String nombreEmprendimiento;
    private String tipoEmpredimiento;
    private String local; //Si: si el empredimiento tiene local y No: si el empredimiento no posee local
    private String entregaDomicilio; //Si y No

    public Emprendedor() {
        super();
    }

    public Emprendedor(String nombreEmprendimiento, String tipoEmpredimiento, String local, String entregaDomicilio, String cedula, String nombre, String apellido, String direccion, String celular, String edad, String usuario, String contraseña) {
        super(cedula, nombre, apellido, direccion, celular, edad, usuario, contraseña);
        this.nombreEmprendimiento = nombreEmprendimiento;
        this.tipoEmpredimiento = tipoEmpredimiento;
        this.local = local;
        this.entregaDomicilio = entregaDomicilio;
    }

    public String getNombreEmprendimiento() {
        return nombreEmprendimiento;
    }

    public void setNombreEmprendimiento(String nombreEmprendimiento) {
        this.nombreEmprendimiento = nombreEmprendimiento;
    }

    public String getTipoEmpredimiento() {
        return tipoEmpredimiento;
    }

    public void setTipoEmpredimiento(String tipoEmpredimiento) {
        this.tipoEmpredimiento = tipoEmpredimiento;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getEntregaDomicilio() {
        return entregaDomicilio;
    }

    public void setEntregaDomicilio(String entregaDomicilio) {
        this.entregaDomicilio = entregaDomicilio;
    }
    
    
    
}
